# -*- coding: utf-8 -*-
"""
import_nuevos_enlaces.py — Importador seguro de nuevos enlaces para Siestas.
Uso: python import_nuevos_enlaces.py <archivo.txt>

Reglas:
  - Filtra todo enlace con "4K" o "[4K]" en el título
  - NO añade duplicados (misma URL ya existente en el catálogo)
  - NO añade duplicados título+calidad dentro de la misma sección
  - Clasifica automáticamente en películas, series o documentales
  - Añade a sección de Estrenos/Recientes Y a Orden Alfabético
"""
import json
import sys
import re
import os
from collections import defaultdict

sys.stdout.reconfigure(encoding='utf-8')

ADDON = r'C:\Users\LBJ\AppData\Roaming\Kodi\addons\plugin.video.Siestas'

def load_json(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_json(path, data):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def extract_quality(titulo):
    m = re.search(r'\[(.*?)\]', titulo)
    if m:
        return m.group(1).strip().lower()
    return 'unknown'

def clean_title_for_compare(titulo):
    clean = re.sub(r'\[.*?\]|\(.*?\)', '', titulo)
    clean = re.sub(
        r'\b(4K|HDR|UHD|2160p|1080p|720p|BluRay|BDremux|MicroHD|'
        r'FullBluRay|DVDRip|3D|HDTV|BDRip|Screener|HdRip)\b',
        '', clean, flags=re.IGNORECASE
    )
    return clean.strip().lower()

def collect_all_urls(nodo):
    """Recorre todo el JSON y devuelve un set con TODAS las URLs."""
    urls = set()
    if isinstance(nodo, list):
        for item in nodo:
            u = item.get('url', '')
            if u:
                urls.add(u)
    elif isinstance(nodo, dict):
        for v in nodo.values():
            urls.update(collect_all_urls(v))
    return urls

def collect_title_quality_keys(lista):
    """Devuelve set de claves título+calidad de una lista."""
    keys = set()
    for item in lista:
        titulo = item.get('titulo', '')
        tq = f"{clean_title_for_compare(titulo)}||{extract_quality(titulo)}"
        keys.add(tq)
    return keys

def is_4k(titulo):
    return bool(re.search(r'4K|2160p|UHD', titulo, re.IGNORECASE))

def parse_txt(filepath):
    """Parsea un txt con formato: titulo\\nURL (alternando líneas)."""
    entries = []
    with open(filepath, 'r', encoding='utf-8') as f:
        lines = [l.strip() for l in f if l.strip()]
    
    i = 0
    while i < len(lines) - 1:
        titulo = lines[i]
        url = lines[i + 1]
        if url.startswith('http') or url.startswith('magnet:'):
            entries.append({'titulo': titulo, 'url': url})
            i += 2
        else:
            i += 1
    return entries

def classify_entry(titulo):
    """Clasifica un entry como pelicula, serie o documental."""
    titulo_lower = titulo.lower()
    # Series: contienen "Capítulo", "Temporada", patrones S01E01, etc.
    if re.search(r'cap[ií]tulo|\d+x\d+|temporada|s\d{2}e\d{2}', titulo_lower):
        return 'serie'
    return 'pelicula'

def get_alpha_key(titulo):
    """Obtiene la letra inicial para el orden alfabético."""
    clean = re.sub(r'^(el |la |los |las |un |una |the |a )', '', titulo.lower()).strip()
    first = clean[0].upper() if clean else '#'
    if not first.isalpha():
        first = '#'
    return first


def import_file(filepath):
    print(f"\n📂 Importando: {filepath}")
    entries = parse_txt(filepath)
    print(f"   Entradas encontradas: {len(entries)}")
    
    # Filtrar 4K
    pre_filter = len(entries)
    entries = [e for e in entries if not is_4k(e['titulo'])]
    filtered_4k = pre_filter - len(entries)
    if filtered_4k:
        print(f"   ❌ Filtradas por 4K: {filtered_4k}")
    
    # Cargar catálogos
    cat_pelis = load_json(f'{ADDON}/catalogo.json')
    cat_series = load_json(f'{ADDON}/catalogo_series.json')
    
    # Recoger TODAS las URLs existentes
    all_urls = set()
    all_urls.update(collect_all_urls(cat_pelis))
    all_urls.update(collect_all_urls(cat_series))
    print(f"   URLs existentes en catálogos: {len(all_urls)}")
    
    # Clasificar y filtrar duplicados
    nuevas_pelis = []
    nuevas_series = []
    duplicadas = 0
    
    for entry in entries:
        if entry['url'] in all_urls:
            duplicadas += 1
            continue
        
        tipo = classify_entry(entry['titulo'])
        if tipo == 'pelicula':
            nuevas_pelis.append(entry)
        else:
            nuevas_series.append(entry)
        all_urls.add(entry['url'])
    
    print(f"   ⏭ Duplicados omitidos (URL ya existente): {duplicadas}")
    print(f"   🎬 Nuevas películas: {len(nuevas_pelis)}")
    print(f"   📺 Nuevas series/eps: {len(nuevas_series)}")
    
    # --- Insertar películas ---
    if nuevas_pelis:
        pelis = cat_pelis.get('Peliculas', {})
        
        # Buscar sección de estrenos
        estrenos_key = None
        for k in pelis.keys():
            if 'estrenos' in k.lower() or 'recientes' in k.lower():
                estrenos_key = k
                break
        if not estrenos_key:
            estrenos_key = '🆕 Estrenos (últimos 3 meses)'
        
        if estrenos_key not in pelis:
            pelis[estrenos_key] = []
        
        # Dedup título+calidad dentro de estrenos
        existing_tq = collect_title_quality_keys(pelis[estrenos_key])
        added_estrenos = 0
        for p in nuevas_pelis:
            tq = f"{clean_title_for_compare(p['titulo'])}||{extract_quality(p['titulo'])}"
            if tq not in existing_tq:
                pelis[estrenos_key].append(p)
                existing_tq.add(tq)
                added_estrenos += 1
        
        # Añadir a Orden Alfabético
        alfa_key = '🔤 Orden Alfabético'
        if alfa_key not in pelis:
            pelis[alfa_key] = {}
        
        added_alfa = 0
        for p in nuevas_pelis:
            letra = get_alpha_key(p['titulo'])
            if letra not in pelis[alfa_key]:
                pelis[alfa_key][letra] = []
            
            existing_tq_letra = collect_title_quality_keys(pelis[alfa_key][letra])
            tq = f"{clean_title_for_compare(p['titulo'])}||{extract_quality(p['titulo'])}"
            if tq not in existing_tq_letra:
                pelis[alfa_key][letra].append(p)
                added_alfa += 1
        
        cat_pelis['Peliculas'] = pelis
        save_json(f'{ADDON}/catalogo.json', cat_pelis)
        print(f"   ✅ Películas añadidas: {added_estrenos} a Estrenos, {added_alfa} a Alfabético")
    
    # --- Insertar series ---
    if nuevas_series:
        # Agrupar por nombre de serie
        series_agrupadas = defaultdict(list)
        for s in nuevas_series:
            # Extraer nombre de serie del título (antes de "Capítulo" o patrón)
            titulo = s['titulo']
            match = re.match(r'^(.+?)\s*[-–]\s*(Cap[ií]tulo|Temporada|\d+x\d+)', titulo)
            if match:
                nombre_serie = match.group(1).strip()
            else:
                nombre_serie = re.sub(r'\[.*?\]', '', titulo).strip()
            
            cap_titulo = titulo
            series_agrupadas[nombre_serie].append({'titulo': cap_titulo, 'url': s['url']})
        
        recientes_key = None
        for k in cat_series.keys():
            if 'recientes' in k.lower():
                recientes_key = k
                break
        if not recientes_key:
            recientes_key = '🆕 Recientes (3 meses)'
        
        if recientes_key not in cat_series:
            cat_series[recientes_key] = {}
        
        added_series = 0
        for nombre, caps in series_agrupadas.items():
            if nombre not in cat_series[recientes_key]:
                cat_series[recientes_key][nombre] = []
            
            existing_urls = {c['url'] for c in cat_series[recientes_key][nombre]}
            for cap in caps:
                if cap['url'] not in existing_urls:
                    cat_series[recientes_key][nombre].append(cap)
                    existing_urls.add(cap['url'])
                    added_series += 1
        
        save_json(f'{ADDON}/catalogo_series.json', cat_series)
        print(f"   ✅ Episodios de series añadidos: {added_series}")
    
    print("\n✅ Importación completada sin duplicados.")


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("Uso: python import_nuevos_enlaces.py <archivo.txt>")
        print("Ejemplo: python import_nuevos_enlaces.py 'C:\\Users\\LBJ\\Desktop\\rastreo\\Ultimos estrenos.txt'")
        sys.exit(1)
    
    import_file(sys.argv[1])
