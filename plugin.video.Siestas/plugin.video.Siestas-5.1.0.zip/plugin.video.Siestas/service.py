# -*- coding: utf-8 -*-
"""
SIESTAS - Servicio de monitorización de reproducción.
Detecta cuándo una película supera el 80% de visionado y la marca como vista.
Para series, marca el capítulo como visto al finalizar la reproducción.
"""
import os
import json
import datetime
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

addon = xbmcaddon.Addon()
addon_data = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
WATCHED_PATH = os.path.join(addon_data, 'peliculas_vistas.json')
SERIES_WATCHED_PATH = os.path.join(addon_data, 'series_vistas.json')

if not os.path.exists(addon_data):
    os.makedirs(addon_data, exist_ok=True)


def save_movie_watched(titulo, url):
    """Guarda una película en la lista de vistas."""
    watched = []
    if os.path.exists(WATCHED_PATH):
        try:
            with open(WATCHED_PATH, 'r', encoding='utf-8') as f:
                watched = json.load(f)
        except Exception:
            watched = []

    for w in watched:
        if w.get('url') == url:
            return False  # Ya existe

    watched.append({
        "titulo": titulo,
        "url": url,
        "timestamp": str(datetime.datetime.now())
    })

    try:
        with open(WATCHED_PATH, 'w', encoding='utf-8') as f:
            json.dump(watched, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        xbmc.log(f"SIESTAS Service: Error guardando película vista: {e}", xbmc.LOGERROR)
        return False


def save_episode_watched(serie, temporada, capitulo, url):
    """Guarda un capítulo en la lista de series vistas."""
    watched = {}
    if os.path.exists(SERIES_WATCHED_PATH):
        try:
            with open(SERIES_WATCHED_PATH, 'r', encoding='utf-8') as f:
                watched = json.load(f)
        except Exception:
            watched = {}

    if serie not in watched:
        watched[serie] = {}
    if temporada not in watched[serie]:
        watched[serie][temporada] = []

    for cap in watched[serie][temporada]:
        if cap.get('url') == url:
            return False  # Ya existe

    watched[serie][temporada].append({
        "titulo": capitulo,
        "url": url,
        "timestamp": str(datetime.datetime.now())
    })

    try:
        with open(SERIES_WATCHED_PATH, 'w', encoding='utf-8') as f:
            json.dump(watched, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        xbmc.log(f"SIESTAS Service: Error guardando capítulo visto: {e}", xbmc.LOGERROR)
        return False


class SiestasPlayer(xbmc.Player):
    """Player personalizado que monitoriza la reproducción de contenido Siestas."""

    def __init__(self):
        super().__init__()
        self._reset()

    def _reset(self):
        self.is_siestas = False
        self.marked = False
        self.content_type = None
        self.titulo = ""
        self.url = ""
        self.serie = ""
        self.temporada = ""
        self.capitulo = ""

    def onAVStarted(self):
        """Se ejecuta cuando el vídeo comienza a reproducirse."""
        win = xbmcgui.Window(10000)
        playing = win.getProperty('siestas.playing')

        if playing == 'true':
            self.is_siestas = True
            self.marked = False
            self.content_type = win.getProperty('siestas.content_type') or 'movie'
            self.titulo = win.getProperty('siestas.titulo') or ''
            self.url = win.getProperty('siestas.url') or ''
            self.serie = win.getProperty('siestas.serie') or ''
            self.temporada = win.getProperty('siestas.temporada') or ''
            self.capitulo = win.getProperty('siestas.capitulo') or ''

            # Limpiar las propiedades para que no se reutilicen
            win.clearProperty('siestas.playing')
            win.clearProperty('siestas.content_type')
            win.clearProperty('siestas.titulo')
            win.clearProperty('siestas.url')
            win.clearProperty('siestas.serie')
            win.clearProperty('siestas.temporada')
            win.clearProperty('siestas.capitulo')

            xbmc.log(f"SIESTAS Service: Reproducción detectada - {self.content_type}: {self.titulo}", xbmc.LOGINFO)
        else:
            self._reset()

    def onPlayBackEnded(self):
        """Se ejecuta cuando el vídeo termina naturalmente."""
        if self.is_siestas and not self.marked:
            self._mark_watched()
        self._reset()

    def onPlayBackStopped(self):
        """Se ejecuta cuando el usuario para el vídeo manualmente."""
        # Para películas: ya se habrá marcado en check_progress si pasó del 80%
        # Para series: NO marcamos al parar, solo al terminar o con menú contextual
        self._reset()

    def check_progress(self):
        """Comprueba el progreso de reproducción (películas al 85%, episodios al 88%)."""
        if not self.is_siestas or self.marked:
            return

        try:
            if not self.isPlaying():
                return
            total = self.getTotalTime()
            current = self.getTime()
            if total <= 0:
                return

            progress = current / total
            if self.content_type == 'movie' and progress >= 0.85:
                self._mark_watched()
            elif self.content_type == 'episode' and progress >= 0.88:
                self._mark_watched()
        except Exception:
            pass

    def _mark_watched(self):
        """Marca el contenido actual como visto."""
        if self.marked:
            return

        if self.content_type == 'movie':
            if self.url and save_movie_watched(self.titulo, self.url):
                xbmc.log(f"SIESTAS Service: Película marcada como vista: {self.titulo}", xbmc.LOGINFO)
                xbmcgui.Dialog().notification("SIESTAS", f"✔ Vista: {self.titulo[:40]}", xbmcgui.NOTIFICATION_INFO, 3000)
        elif self.content_type == 'episode':
            if self.url and self.serie and self.temporada and self.capitulo:
                if save_episode_watched(self.serie, self.temporada, self.capitulo, self.url):
                    xbmc.log(f"SIESTAS Service: Capítulo marcado como visto: {self.serie} - {self.capitulo}", xbmc.LOGINFO)
                    xbmcgui.Dialog().notification("SIESTAS", f"✔ Visto: {self.capitulo[:40]}", xbmcgui.NOTIFICATION_INFO, 3000)

        self.marked = True


def main():
    """Bucle principal del servicio."""
    xbmc.log("SIESTAS Service: Iniciando servicio de monitorización...", xbmc.LOGINFO)

    monitor = xbmc.Monitor()
    player = SiestasPlayer()

    while not monitor.abortRequested():
        # Comprobar progreso cada 10 segundos
        if player.is_siestas and not player.marked:
            player.check_progress()

        if monitor.waitForAbort(10):
            break

    xbmc.log("SIESTAS Service: Servicio detenido.", xbmc.LOGINFO)


if __name__ == '__main__':
    main()
