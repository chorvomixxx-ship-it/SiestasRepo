# -*- coding: utf-8 -*-
import sys
import os
import json
import re
import threading
import urllib.request
import urllib.parse
from concurrent.futures import ThreadPoolExecutor
import difflib
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from urllib.parse import parse_qsl, quote_plus, unquote_plus

# ==========================================
# Configuración del Addon
# ==========================================
addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
addon_data = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
icon = os.path.join(addon_path, 'portada.jpg')
fanart = os.path.join(addon_path, 'fanart.jpg')

CATALOG_PATH = os.path.join(addon_path, 'catalogo.json')
SERIES_PATH = os.path.join(addon_path, 'catalogo_series.json')
CACHE_PATH = os.path.join(addon_path, 'tmdb_cache.json')
FAVS_PATH = os.path.join(addon_data, 'favoritos.json')
SERIES_FAVS_PATH = os.path.join(addon_data, 'favoritos_series.json')
TMDB_API_KEY = "f090bb54758cabf231fb605d3e3e0468"

# Asegurar que existe el directorio de datos del addon
if not os.path.exists(addon_data):
    os.makedirs(addon_data, exist_ok=True)


# ==========================================
# Gestor de Favoritos
# ==========================================
class FavoritesManager:
    """Gestiona favoritos con almacenamiento persistente."""

    @staticmethod
    def load():
        if os.path.exists(FAVS_PATH):
            try:
                with open(FAVS_PATH, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                return []
        return []

    @staticmethod
    def save(favs):
        try:
            with open(FAVS_PATH, 'w', encoding='utf-8') as f:
                json.dump(favs, f, ensure_ascii=False, indent=2)
        except Exception as e:
            xbmc.log(f"SIESTAS Error guardando favoritos: {e}", xbmc.LOGERROR)

    @staticmethod
    def add(titulo, url):
        favs = FavoritesManager.load()
        for f in favs:
            if f.get('url') == url:
                return False  # Ya existe
        favs.append({"titulo": titulo, "url": url})
        FavoritesManager.save(favs)
        return True

    @staticmethod
    def remove(url):
        favs = FavoritesManager.load()
        nuevos = [f for f in favs if f.get('url') != url]
        FavoritesManager.save(nuevos)
        return len(nuevos) < len(favs)

    @staticmethod
    def is_fav(url):
        favs = FavoritesManager.load()
        return any(f.get('url') == url for f in favs)

class SeriesFavoritesManager:
    """Gestiona favoritos de series con almacenamiento persistente."""

    @staticmethod
    def load():
        if os.path.exists(SERIES_FAVS_PATH):
            try:
                with open(SERIES_FAVS_PATH, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception:
                return []
        return []

    @staticmethod
    def save(favs):
        try:
            with open(SERIES_FAVS_PATH, 'w', encoding='utf-8') as f:
                json.dump(favs, f, ensure_ascii=False, indent=2)
        except Exception as e:
            xbmc.log(f"SIESTAS Error guardando favoritos series: {e}", xbmc.LOGERROR)

    @staticmethod
    def add(titulo, path):
        favs = SeriesFavoritesManager.load()
        for f in favs:
            if f.get('path') == path:
                return False
        favs.append({"titulo": titulo, "path": path})
        SeriesFavoritesManager.save(favs)
        return True

    @staticmethod
    def remove(path):
        favs = SeriesFavoritesManager.load()
        nuevos = [f for f in favs if f.get('path') != path]
        SeriesFavoritesManager.save(nuevos)
        return len(nuevos) < len(favs)

    @staticmethod
    def is_fav(path):
        favs = SeriesFavoritesManager.load()
        return any(f.get('path') == path for f in favs)


# ==========================================
# Motor TMDB
# ==========================================
class TMDBFetcher:
    """Motor de metadatos TMDB con caché persistente y thread-safe."""
    _cache_data = None
    _lock = threading.Lock()

    @staticmethod
    def load_cache():
        if TMDBFetcher._cache_data is None:
            if os.path.exists(CACHE_PATH):
                try:
                    with open(CACHE_PATH, 'r', encoding='utf-8') as f:
                        TMDBFetcher._cache_data = json.load(f)
                except Exception:
                    TMDBFetcher._cache_data = {}
            else:
                TMDBFetcher._cache_data = {}

    @staticmethod
    def save_cache():
        with TMDBFetcher._lock:
            try:
                with open(CACHE_PATH, 'w', encoding='utf-8') as f:
                    json.dump(TMDBFetcher._cache_data, f, ensure_ascii=False)
            except Exception as e:
                xbmc.log(f"SIESTAS Error guardando cache: {e}", xbmc.LOGERROR)

    @staticmethod
    def clean_title(title):
        """Limpia el título eliminando etiquetas de calidad y formato."""
        clean = re.sub(r'\[.*?\]|\(.*?\)', '', title)
        clean = re.sub(
            r'\b(4K|HDR|UHD|2160p|1080p|720p|BluRay|BDremux|MicroHD|'
            r'FullBluRay|DVDRip|3D|HDTV|BDRip|V\s*Extendida|Screener)\b',
            '', clean, flags=re.IGNORECASE
        )
        return clean.strip()

    @staticmethod
    def _tmdb_request(url):
        """Hace una petición a TMDB y devuelve el JSON."""
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'Kodi-Siestas/4.3'})
            with urllib.request.urlopen(req, timeout=5) as response:
                return json.loads(response.read().decode('utf-8'))
        except Exception:
            return None

    @staticmethod
    def get_metadata(title, is_series=False):
        """Obtiene metadatos de TMDB para una película o serie."""
        TMDBFetcher.load_cache()
        clean = TMDBFetcher.clean_title(title)
        
        # Para distinguir en cache entre peli y serie, aunque suelen tener nombres distintos,
        # añadimos un prefijo invisible si es serie
        cache_key = f"TV_{clean}" if is_series else clean

        with TMDBFetcher._lock:
            if cache_key in TMDBFetcher._cache_data:
                cached = TMDBFetcher._cache_data[cache_key]
                if cached is not None:
                    return cached

        query = quote_plus(clean)
        
        if is_series:
            url = (f"https://api.themoviedb.org/3/search/tv?"
                   f"api_key={TMDB_API_KEY}&language=es-ES&query={query}&page=1")
        else:
            url = (f"https://api.themoviedb.org/3/search/movie?"
                   f"api_key={TMDB_API_KEY}&language=es-ES&query={query}&page=1")

        data = TMDBFetcher._tmdb_request(url)
        result_meta = None
        if data and data.get('results'):
            results = data['results']
            best_item = results[0]
            title_key = 'name' if is_series else 'title'
            orig_title_key = 'original_name' if is_series else 'original_title'

            clean_lower = clean.lower()
            best_ratio = 0
            for item in results:
                t1 = (item.get(title_key) or '').lower()
                t2 = (item.get(orig_title_key) or '').lower()
                r1 = difflib.SequenceMatcher(None, clean_lower, t1).ratio()
                r2 = difflib.SequenceMatcher(None, clean_lower, t2).ratio()
                if max(r1, r2) > best_ratio:
                    best_ratio = max(r1, r2)
                    best_item = item
                if best_ratio > 0.95:
                    break

            item = best_item
            poster = f"https://image.tmdb.org/t/p/w500{item['poster_path']}" if item.get('poster_path') else ''
            bg = f"https://image.tmdb.org/t/p/w1280{item['backdrop_path']}" if item.get('backdrop_path') else ''
            
            title_key = 'name' if is_series else 'title'
            date_key = 'first_air_date' if is_series else 'release_date'
            
            result_meta = {
                'title': item.get(title_key) or title,
                'plot': item.get('overview', 'Sin sinopsis disponible.'),
                'rating': float(item.get('vote_average', 0.0)),
                'year': str(item.get(date_key, '')[:4] if item.get(date_key) else ''),
                'poster': poster,
                'fanart': bg
            }

        if result_meta is not None:
            with TMDBFetcher._lock:
                TMDBFetcher._cache_data[cache_key] = result_meta
        return result_meta

    @staticmethod
    def search_person_movies(person_name, role='actor'):
        """Busca una persona en TMDB y devuelve los títulos de sus películas."""
        query = quote_plus(person_name)
        url = f"https://api.themoviedb.org/3/search/person?api_key={TMDB_API_KEY}&language=es-ES&query={query}"
        data = TMDBFetcher._tmdb_request(url)
        if not data or not data.get('results'):
            return []

        person_id = data['results'][0]['id']
        credits_url = f"https://api.themoviedb.org/3/person/{person_id}/movie_credits?api_key={TMDB_API_KEY}&language=es-ES"
        credits = TMDBFetcher._tmdb_request(credits_url)
        if not credits:
            return []

        key = 'cast' if role == 'actor' else 'crew'
        movies = credits.get(key, [])
        titles = []
        for m in movies:
            if role == 'director' and m.get('job') != 'Director':
                continue
            t = m.get('title', '')
            if t:
                titles.append(t.lower())
        return titles


# ==========================================
# Motor Principal del Addon
# ==========================================
class JSONEngine:
    """Motor principal del addon. Navega el catálogo JSON y reproduce contenido."""

    def __init__(self):
        self.handle = int(sys.argv[1])
        self.url = sys.argv[0]
        self.params = dict(parse_qsl(sys.argv[2][1:]))
        self._peliculas = None
        self._series = None

    def _load_json(self, path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            xbmc.log(f"SIESTAS Error leyendo {path}: {e}", xbmc.LOGERROR)
            return {}

    @property
    def peliculas(self):
        if self._peliculas is None:
            data = self._load_json(CATALOG_PATH)
            self._peliculas = data.get('Peliculas', {})
        return self._peliculas

    @property
    def series(self):
        if self._series is None:
            self._series = self._load_json(SERIES_PATH)
        return self._series

    def _build_url(self, mode, **kwargs):
        base = f"{self.url}?mode={mode}"
        for k, v in kwargs.items():
            base += f"&{k}={quote_plus(str(v))}"
        return base

    def run(self):
        mode = self.params.get('mode')
        if not mode or mode == 'browse':
            self.browse_catalogo(self.params.get('path', ''))
        elif mode == 'reproducir':
            self.reproducir(self.params.get('video_url'), self.params.get('title'))
        elif mode == 'buscar':
            self.buscar(self.params.get('tipo', 'Peliculas'))
        elif mode == 'buscar_titulo':
            self._buscar_por_titulo(self.params.get('tipo', 'Peliculas'), self.params.get('query', ''))
        elif mode == 'buscar_actor':
            self._buscar_por_persona(self.params.get('tipo', 'Peliculas'), 'actor', self.params.get('query', ''))
        elif mode == 'buscar_director':
            self._buscar_por_persona(self.params.get('tipo', 'Peliculas'), 'director', self.params.get('query', ''))
        elif mode == 'buscar_anio':
            self._buscar_por_anio(self.params.get('tipo', 'Peliculas'), self.params.get('query', ''))
        elif mode == 'buscar_calidad':
            self._buscar_por_calidad(self.params.get('tipo', 'Peliculas'), self.params.get('query', ''))
        elif mode == 'favoritos':
            self.mostrar_favoritos()
        elif mode == 'favoritos_series':
            self.mostrar_favoritos_series()
        elif mode == 'add_fav':
            titulo = unquote_plus(self.params.get('title', ''))
            url_vid = unquote_plus(self.params.get('video_url', ''))
            if FavoritesManager.add(titulo, url_vid):
                xbmcgui.Dialog().notification("SIESTAS", "Añadido a Favoritos", xbmcgui.NOTIFICATION_INFO, 2000)
            else:
                xbmcgui.Dialog().notification("SIESTAS", "Ya está en Favoritos", xbmcgui.NOTIFICATION_INFO, 2000)
            xbmc.executebuiltin('Container.Refresh')
        elif mode == 'remove_fav':
            url_vid = unquote_plus(self.params.get('video_url', ''))
            if FavoritesManager.remove(url_vid):
                xbmcgui.Dialog().notification("SIESTAS", "Eliminado de Favoritos", xbmcgui.NOTIFICATION_INFO, 2000)
            xbmc.executebuiltin('Container.Refresh')
        elif mode == 'add_fav_serie':
            nombre = unquote_plus(self.params.get('serie_name', ''))
            path = unquote_plus(self.params.get('serie_path', ''))
            self._add_serie_fav(nombre, path)
        elif mode == 'remove_fav_serie':
            nombre = unquote_plus(self.params.get('serie_name', ''))
            self._remove_serie_fav(nombre)

    def _get_node(self, path_str):
        if not path_str:
            return None
        keys = path_str.split('|')
        root = keys[0]
        if root == 'Peliculas':
            node = self.peliculas
        elif root == 'Series':
            node = self.series
        else:
            return None
        for k in keys[1:]:
            if isinstance(node, dict) and k in node:
                node = node[k]
            else:
                return None
        return node

    def _is_series_path(self, path_str):
        return path_str.startswith('Series')

    def browse_catalogo(self, path_str):
        # Nivel raíz: Películas y Series
        if not path_str:
            self.add_dir(f"[B][COLOR darkorange]● PELÍCULAS[/COLOR][/B]", self._build_url('browse', path='Peliculas'))
            self.add_dir(f"[B][COLOR darkorange]● SERIES[/COLOR][/B]", self._build_url('browse', path='Series'))
            xbmcplugin.endOfDirectory(self.handle)
            return

        node = self._get_node(path_str)
        if node is None:
            xbmcplugin.endOfDirectory(self.handle)
            return

        is_series = self._is_series_path(path_str)
        
        # Submenús iniciales
        if path_str == 'Peliculas':
            fav_count = len(FavoritesManager.load())
            self.add_dir(f"[B][COLOR gold]★ MIS FAVORITOS PELIS[/COLOR][/B] [COLOR dimgray]({fav_count})[/COLOR]", self._build_url('favoritos'))
            self.add_dir(f"[I][COLOR dodgerblue]🔍 Buscar Película...[/COLOR][/I]", self._build_url('buscar', tipo='Peliculas'))
        elif path_str == 'Series':
            sfavs_count = len(SeriesFavoritesManager.load())
            self.add_dir(f"[B][COLOR gold]★ MIS FAVORITOS SERIES[/COLOR][/B] [COLOR dimgray]({sfavs_count})[/COLOR]", self._build_url('favoritos_series'))
            self.add_dir(f"[I][COLOR dodgerblue]🔍 Buscar Serie...[/COLOR][/I]", self._build_url('buscar', tipo='Series'))

        if isinstance(node, dict):
            # Pre-fetch metadata si estamos en el nivel de títulos de series
            is_series_title_level = False
            if is_series and path_str:
                keys = path_str.split('|')
                if len(keys) >= 2:
                    if keys[1] == '🔤 Orden Alfabético':
                        is_series_title_level = (len(keys) == 3)
                    else:
                        is_series_title_level = (len(keys) == 2)
            
            if is_series_title_level:
                def prefetch(title):
                    TMDBFetcher.get_metadata(title, is_series=True)
                with ThreadPoolExecutor(max_workers=5) as executor:
                    executor.map(prefetch, node.keys())
                TMDBFetcher.save_cache()

            for k in node.keys():
                child = node[k]
                if isinstance(child, dict) and len(child) == 0:
                    continue
                if isinstance(child, list) and len(child) == 0:
                    continue

                new_path = f"{path_str}|{k}"
                keys_np = new_path.split('|')
                depth = len(keys_np)
                
                # Limpiar emojis para la vista en pantalla
                clean_k = re.sub(r'[^\w\s\(\)\-\.,\'¡!¿?]', '', k).strip()
                
                # Nivel de sección (Ej: Recientes, Orden Alfabético)
                if depth == 2:
                    display_name = f"[B][COLOR white]▶ {clean_k}[/COLOR][/B]"
                elif is_series and depth >= 3:
                    # Nivel de serie o temporada
                    count = len(child) if isinstance(child, (list, dict)) else 0
                    
                    is_title = False
                    if keys_np[1] == '🔤 Orden Alfabético':
                        is_title = (depth == 4)
                    else:
                        is_title = (depth == 3)

                    if is_title:
                        display_name = f"[B][COLOR white]  {clean_k}[/COLOR][/B] [COLOR dimgray]({count})[/COLOR]"
                    else:
                        display_name = f"[B][COLOR darkorange]● {clean_k}[/COLOR][/B] [COLOR dimgray]({count})[/COLOR]"
                    item = xbmcgui.ListItem(display_name)
                    
                    # Añadir metadatos si estamos en el nivel de título de serie
                    if is_title:
                        meta = TMDBFetcher.get_metadata(k, is_series=True)
                        if meta:
                            item.setArt({'icon': meta.get('poster', icon), 'thumb': meta.get('poster', icon), 'fanart': meta.get('fanart', fanart), 'poster': meta.get('poster', icon)})
                            
                            plot = meta.get('plot', '')
                            rating = meta.get('rating', 0.0)
                            year = meta.get('year', '')
                            try:
                                info_tag = item.getVideoInfoTag()
                                info_tag.setTitle(k)
                                info_tag.setPlot(plot)
                                info_tag.setRating(rating)
                                info_tag.setMediaType('tvshow')
                                if year:
                                    try: info_tag.setYear(int(year))
                                    except: pass
                            except AttributeError:
                                info = {"title": k, "plot": plot, "rating": rating}
                                if year:
                                    try: info["year"] = int(year)
                                    except: pass
                                item.setInfo(type="Video", infoLabels=info)
                        else:
                            item.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
                    else:
                        item.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
                    
                    ctx_menu = []
                    # Solo añadir favoritos en el nivel de Título de Serie
                    if is_title:
                        if SeriesFavoritesManager.is_fav(new_path):
                            rm_url = self._build_url('remove_fav_serie', serie_name=k)
                            ctx_menu.append(("❌ Quitar Serie de Favoritos", f"RunPlugin({rm_url})"))
                        else:
                            add_url = self._build_url('add_fav_serie', serie_name=k, serie_path=new_path)
                            ctx_menu.append(("⭐ Añadir Serie a Favoritos", f"RunPlugin({add_url})"))
                            
                    if ctx_menu:
                        item.addContextMenuItems(ctx_menu)
                        
                    xbmcplugin.addDirectoryItem(self.handle, self._build_url('browse', path=new_path), item, isFolder=True)
                    continue
                else:
                    count = len(child) if isinstance(child, (list, dict)) else 0
                    display_name = f"[B][COLOR white]▶ {clean_k}[/COLOR][/B] [COLOR dimgray]({count})[/COLOR]"

                self.add_dir(display_name, self._build_url('browse', path=new_path))
            xbmcplugin.endOfDirectory(self.handle)

        elif isinstance(node, list):
            if not node:
                xbmcplugin.endOfDirectory(self.handle)
                return
            if is_series:
                self._mostrar_lista_capitulos(node, path_str)
            else:
                self._mostrar_lista_pelis(node)

    def _mostrar_lista_capitulos(self, lista, path_str):
        keys = path_str.split('|')
        if len(keys) >= 3:
            if keys[1] == '🔤 Orden Alfabético' and len(keys) >= 4:
                titulo_serie = keys[3]
            else:
                titulo_serie = keys[2]
        else:
            titulo_serie = "Serie"

        # Ya no obtenemos la portada de la serie para los capítulos.
        # Usamos los logos e imágenes por defecto de Siestas (el chico y el perro).
        caratula, fondo, plot, rating, year = icon, fanart, "", 0.0, ""

        for cap in lista:
            titulo_cap = cap.get("titulo", "Capítulo")
            url = cap.get("url", "")
            self.add_video(f"{titulo_serie} - {titulo_cap}", url, caratula, fondo, plot, rating, year)

        xbmcplugin.setContent(self.handle, 'episodes')
        xbmcplugin.endOfDirectory(self.handle)

    def _add_serie_fav(self, nombre, path):
        if SeriesFavoritesManager.add(nombre, path):
            xbmcgui.Dialog().notification("SIESTAS", "⭐ Serie Añadida a Favoritos", xbmcgui.NOTIFICATION_INFO, 2000)
        else:
            xbmcgui.Dialog().notification("SIESTAS", "La serie ya está en favoritos", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin('Container.Refresh')

    def _remove_serie_fav(self, nombre):
        favs = SeriesFavoritesManager.load()
        path = None
        for f in favs:
            if f.get('titulo') == nombre:
                path = f.get('path')
                break
        if path and SeriesFavoritesManager.remove(path):
            xbmcgui.Dialog().notification("SIESTAS", "❌ Serie Eliminada de Favoritos", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin('Container.Refresh')

    def mostrar_favoritos_series(self):
        favs = SeriesFavoritesManager.load()
        if not favs:
            xbmcgui.Dialog().notification("SIESTAS", "No tienes series favoritas aún", xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(self.handle)
            return

        for f in favs:
            nombre = f.get('titulo', 'Serie')
            path = f.get('path', '')
            
            # Recuperamos el nodo de la serie para saber cuántas temporadas tiene
            node = self._get_node(path)
            count = len(node) if isinstance(node, dict) else 0

            display_name = f"[B][COLOR white]  {nombre}[/COLOR][/B] [COLOR dimgray]({count})[/COLOR]"
            item = xbmcgui.ListItem(display_name)
            
            # Obtener arte si es posible
            meta = TMDBFetcher.get_metadata(nombre, is_series=True)
            if meta:
                item.setArt({'icon': meta.get('poster', icon), 'thumb': meta.get('poster', icon), 'fanart': meta.get('fanart', fanart), 'poster': meta.get('poster', icon)})
                
                plot = meta.get('plot', '')
                rating = meta.get('rating', 0.0)
                year = meta.get('year', '')
                try:
                    info_tag = item.getVideoInfoTag()
                    info_tag.setTitle(nombre)
                    info_tag.setPlot(plot)
                    info_tag.setRating(rating)
                    info_tag.setMediaType('tvshow')
                    if year:
                        try: info_tag.setYear(int(year))
                        except: pass
                except AttributeError:
                    info = {"title": nombre, "plot": plot, "rating": rating}
                    if year:
                        try: info["year"] = int(year)
                        except: pass
                    item.setInfo(type="Video", infoLabels=info)
            else:
                item.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})

            ctx_menu = []
            rm_url = self._build_url('remove_fav_serie', serie_name=nombre)
            ctx_menu.append(("❌ Quitar Serie de Favoritos", f"RunPlugin({rm_url})"))
            item.addContextMenuItems(ctx_menu)

            xbmcplugin.addDirectoryItem(self.handle, self._build_url('browse', path=path), item, isFolder=True)

        xbmcplugin.endOfDirectory(self.handle)

    def mostrar_favoritos(self):
        """Muestra las películas guardadas en favoritos."""
        favs = FavoritesManager.load()
        if not favs:
            xbmcgui.Dialog().notification("SIESTAS", "No tienes favoritos aún", xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(self.handle)
            return
        self._mostrar_lista_pelis(favs, paginate=False)

    def _mostrar_lista_pelis(self, lista, paginate=True):
        """Procesa y muestra una lista de películas con metadatos TMDB."""
        if paginate and len(lista) > 50:
            page = int(self.params.get('page', 0))
            items_per_page = 50
            start = page * items_per_page
            end = start + items_per_page
            pagina_actual = lista[start:end]
            has_next = end < len(lista)
        else:
            pagina_actual = lista
            has_next = False
            page = 0

        with ThreadPoolExecutor(max_workers=5) as executor:
            procesados = list(executor.map(self._procesar_video, pagina_actual))
        TMDBFetcher.save_cache()

        for titulo_original, url, meta in procesados:
            caratula, fondo, plot, rating, year = icon, fanart, "", 0.0, ""
            if meta:
                if meta.get('poster'): caratula = meta['poster']
                if meta.get('fanart'): fondo = meta['fanart']
                plot = meta.get('plot', '')
                rating = meta.get('rating', 0.0)
                year = meta.get('year', '')
            self.add_video(f"[B][COLOR white]  {titulo_original}[/COLOR][/B]", url, caratula, fondo, plot, rating, year)

        if has_next:
            kwargs = {k: v for k, v in self.params.items() if k not in ['page', 'video_url', 'title']}
            kwargs['page'] = page + 1
            mode = kwargs.pop('mode', 'browse')
            next_url = self._build_url(mode, **kwargs)
            self.add_dir(f"[B][COLOR yellow]Siguiente Página >>[/COLOR][/B] [COLOR dimgray]({end} de {len(lista)})[/COLOR]", next_url)

        xbmcplugin.setContent(self.handle, 'movies')
        xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_UNSORTED)
        xbmcplugin.endOfDirectory(self.handle)

    # ==========================================
    # Búsqueda Avanzada
    # ==========================================
    def buscar(self, tipo):
        opciones = ["🔤 Por Título", "🎭 Por Actor", "🎬 Por Director", "📅 Por Año", "📀 Por Calidad"]
        seleccion = xbmcgui.Dialog().select("¿Cómo quieres buscar?", opciones)
        if seleccion < 0:
            xbmcplugin.endOfDirectory(self.handle)
            return

        if seleccion == 0:
            self._buscar_por_titulo(tipo)
        elif seleccion == 1:
            self._buscar_por_persona(tipo, 'actor')
        elif seleccion == 2:
            self._buscar_por_persona(tipo, 'director')
        elif seleccion == 3:
            self._buscar_por_anio(tipo)
        elif seleccion == 4:
            self._buscar_por_calidad(tipo)

    def _buscar_por_calidad(self, tipo, query=''):
        if not query:
            keyboard = xbmc.Keyboard('', 'Introduce calidad (ej: 1080p, MicroHD)', False)
            keyboard.doModal()
            if not keyboard.isConfirmed() or not keyboard.getText():
                xbmcplugin.endOfDirectory(self.handle)
                return
            query = keyboard.getText().lower()
            
        self.params['mode'] = 'buscar_calidad'
        self.params['query'] = query

        todas = self._recoger_todas_pelis(tipo)
        # La calidad está guardada en el título original entre corchetes
        resultados = [p for p in todas if query in p.get("titulo", "").lower()]

        if not resultados:
            xbmcgui.Dialog().notification("SIESTAS", "No se encontraron resultados para esa calidad", xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(self.handle)
            return
            
        if tipo == 'Series':
            self._mostrar_lista_series_buscadas(resultados)
        else:
            self._mostrar_lista_pelis(resultados, paginate=True)

    def _recoger_todas_pelis(self, tipo):
        """Recoge TODAS las películas o series del catálogo en una lista plana."""
        todas = []
        urls_vistas = set()
        
        if tipo == 'Peliculas':
            seccion = self.peliculas
            def _recorrer(nodo):
                if isinstance(nodo, list):
                    for peli in nodo:
                        url = peli.get("url", "")
                        if url and url not in urls_vistas:
                            todas.append(peli)
                            urls_vistas.add(url)
                elif isinstance(nodo, dict):
                    for v in nodo.values():
                        _recorrer(v)
            _recorrer(seccion)
        else:
            # Para series, queremos buscar por el nombre de la serie
            seccion = self.series
            
            # Recorremos el diccionario de series
            for categoria, subnodo in seccion.items():
                if categoria == '🔤 Orden Alfabético':
                    for letra, series_letra in subnodo.items():
                        for nombre_serie, temps in series_letra.items():
                            # Añadir el nombre de la serie como un elemento para buscar
                            # Para el resultado de búsqueda, nos llevará al path de la serie
                            path_serie = f"Series|{categoria}|{letra}|{nombre_serie}"
                            if path_serie not in urls_vistas:
                                todas.append({"titulo": nombre_serie, "path": path_serie, "is_serie": True})
                                urls_vistas.add(path_serie)
                else:
                    for nombre_serie, temps in subnodo.items():
                        path_serie = f"Series|{categoria}|{nombre_serie}"
                        if path_serie not in urls_vistas:
                            todas.append({"titulo": nombre_serie, "path": path_serie, "is_serie": True})
                            urls_vistas.add(path_serie)
                            
        return todas

    def _buscar_por_titulo(self, tipo, query=''):
        if not query:
            titulo_teclado = 'Buscar Película' if tipo == 'Peliculas' else 'Buscar Serie'
            keyboard = xbmc.Keyboard('', titulo_teclado, False)
            keyboard.doModal()
            if not keyboard.isConfirmed() or not keyboard.getText():
                xbmcplugin.endOfDirectory(self.handle)
                return
            query = keyboard.getText().lower()
            
        self.params['mode'] = 'buscar_titulo'
        self.params['query'] = query

        todas = self._recoger_todas_pelis(tipo)
        resultados = [p for p in todas if query in p.get("titulo", "").lower()]

        if not resultados:
            xbmcgui.Dialog().notification("SIESTAS", "No se encontraron resultados", xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(self.handle)
            return
            
        if tipo == 'Series':
            self._mostrar_lista_series_buscadas(resultados)
        else:
            self._mostrar_lista_pelis(resultados, paginate=True)

    def _buscar_por_persona(self, tipo, role, query=''):
        label = "Actor" if role == 'actor' else "Director"
        if not query:
            keyboard = xbmc.Keyboard('', f'Nombre del {label}', False)
            keyboard.doModal()
            if not keyboard.isConfirmed() or not keyboard.getText():
                xbmcplugin.endOfDirectory(self.handle)
                return
            nombre = keyboard.getText()
        else:
            nombre = query
            
        self.params['mode'] = 'buscar_' + role
        self.params['query'] = nombre

        pDialog = xbmcgui.DialogProgress()
        pDialog.create("SIESTAS", f"Buscando {tipo.lower()} de {nombre}...")

        # Dependiendo del tipo, la búsqueda en TMDB es diferente
        if tipo == 'Series':
            query_enc = quote_plus(nombre)
            url_search = f"https://api.themoviedb.org/3/search/person?api_key={TMDB_API_KEY}&language=es-ES&query={query_enc}"
            data = TMDBFetcher._tmdb_request(url_search)
            titulos_tmdb = []
            if data and data.get('results'):
                person_id = data['results'][0]['id']
                credits_url = f"https://api.themoviedb.org/3/person/{person_id}/tv_credits?api_key={TMDB_API_KEY}&language=es-ES"
                credits = TMDBFetcher._tmdb_request(credits_url)
                if credits:
                    key = 'cast' if role == 'actor' else 'crew'
                    movies = credits.get(key, [])
                    for m in movies:
                        if role == 'director' and m.get('job') != 'Director':
                            continue
                        t = m.get('name', '')
                        if not t: t = m.get('original_name', '')
                        if t: titulos_tmdb.append(t.lower())
        else:
            titulos_tmdb = TMDBFetcher.search_person_movies(nombre, role)

        if not titulos_tmdb:
            pDialog.close()
            xbmcgui.Dialog().notification("SIESTAS", f"No se encontró al {label}", xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(self.handle)
            return

        pDialog.update(50, f"Cruzando con tu catálogo ({len(titulos_tmdb)} items)...")
        todas = self._recoger_todas_pelis(tipo)

        resultados = []
        for peli in todas:
            titulo_limpio = TMDBFetcher.clean_title(peli.get("titulo", "")).lower()
            if titulo_limpio in titulos_tmdb:
                resultados.append(peli)

        pDialog.close()

        if not resultados:
            xbmcgui.Dialog().notification("SIESTAS",
                f"No tienes {tipo.lower()} de {nombre} en tu catálogo",
                xbmcgui.NOTIFICATION_INFO, 4000)
            xbmcplugin.endOfDirectory(self.handle)
            return
            
        if tipo == 'Series':
            self._mostrar_lista_series_buscadas(resultados)
        else:
            self._mostrar_lista_pelis(resultados, paginate=True)

    def _buscar_por_anio(self, tipo, query=''):
        if not query:
            keyboard = xbmc.Keyboard('', 'Introduce el año (ej: 2025)', False)
            keyboard.doModal()
            if not keyboard.isConfirmed() or not keyboard.getText():
                xbmcplugin.endOfDirectory(self.handle)
                return
            anio = keyboard.getText().strip()
        else:
            anio = query
            
        if not anio.isdigit() or len(anio) != 4:
            xbmcgui.Dialog().notification("SIESTAS", "Año no válido", xbmcgui.NOTIFICATION_WARNING, 3000)
            xbmcplugin.endOfDirectory(self.handle)
            return
            
        self.params['mode'] = 'buscar_anio'
        self.params['query'] = anio

        todas = self._recoger_todas_pelis(tipo)

        TMDBFetcher.load_cache()
        resultados = []
        urls_vistas = set()

        for peli in todas:
            titulo = peli.get("titulo", "")
            
            if tipo == 'Series':
                path = peli.get("path", "")
                if path in urls_vistas:
                    continue
                # Las series a veces tienen año en título, pero consultamos TMDB
                clean = TMDBFetcher.clean_title(titulo)
                with TMDBFetcher._lock:
                    cached = TMDBFetcher._cache_data.get(clean)
                if cached and cached.get('year') == anio:
                    resultados.append(peli)
                    urls_vistas.add(path)
                    continue
                if anio in titulo:
                    resultados.append(peli)
                    urls_vistas.add(path)
            else:
                url = peli.get("url", "")
                if url in urls_vistas:
                    continue

                clean = TMDBFetcher.clean_title(titulo)
                with TMDBFetcher._lock:
                    cached = TMDBFetcher._cache_data.get(clean)
                if cached and cached.get('year') == anio:
                    resultados.append(peli)
                    urls_vistas.add(url)
                    continue

                if anio in titulo:
                    resultados.append(peli)
                    urls_vistas.add(url)

        if not resultados:
            xbmcgui.Dialog().notification("SIESTAS", f"No hay {tipo.lower()} del {anio}", xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(self.handle)
            return
        if tipo == 'Series':
            self._mostrar_lista_series_buscadas(resultados)
        else:
            self._mostrar_lista_pelis(resultados, paginate=True)

    def _mostrar_lista_series_buscadas(self, resultados):
        """Muestra los resultados de búsqueda de series como carpetas."""
        for res in resultados:
            nombre = res.get("titulo", "")
            path = res.get("path", "")
            
            node = self._get_node(path)
            count = len(node) if isinstance(node, dict) else 0

            display_name = f"[B][COLOR white]  {nombre}[/COLOR][/B] [COLOR dimgray]({count})[/COLOR]"
            item = xbmcgui.ListItem(display_name)
            
            meta = TMDBFetcher.get_metadata(nombre, is_series=True)
            if meta:
                item.setArt({'icon': meta.get('poster', icon), 'thumb': meta.get('poster', icon), 'fanart': meta.get('fanart', fanart), 'poster': meta.get('poster', icon)})
                
                plot = meta.get('plot', '')
                rating = meta.get('rating', 0.0)
                year = meta.get('year', '')
                try:
                    info_tag = item.getVideoInfoTag()
                    info_tag.setTitle(nombre)
                    info_tag.setPlot(plot)
                    info_tag.setRating(rating)
                    info_tag.setMediaType('tvshow')
                    if year:
                        try: info_tag.setYear(int(year))
                        except: pass
                except AttributeError:
                    info = {"title": nombre, "plot": plot, "rating": rating}
                    if year:
                        try: info["year"] = int(year)
                        except: pass
                    item.setInfo(type="Video", infoLabels=info)
            else:
                item.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})

            ctx_menu = []
            if SeriesFavoritesManager.is_fav(path):
                rm_url = self._build_url('remove_fav_serie', serie_name=nombre)
                ctx_menu.append(("❌ Quitar Serie de Favoritos", f"RunPlugin({rm_url})"))
            else:
                add_url = self._build_url('add_fav_serie', serie_name=nombre, serie_path=path)
                ctx_menu.append(("⭐ Añadir Serie a Favoritos", f"RunPlugin({add_url})"))
            item.addContextMenuItems(ctx_menu)

            xbmcplugin.addDirectoryItem(self.handle, self._build_url('browse', path=path), item, isFolder=True)
            
        xbmcplugin.endOfDirectory(self.handle)

    # ==========================================
    # Procesamiento de Vídeos
    # ==========================================
    def _procesar_video(self, video):
        titulo_original = video.get("titulo", "Sin Título")
        url = video.get("url", "")
        meta = TMDBFetcher.get_metadata(titulo_original)
        return (titulo_original, url, meta)

    def reproducir(self, video_url, title):
        """Reproduce contenido. Fix crítico: manejo correcto de torrents con Elementum."""
        video_url = unquote_plus(video_url) if video_url else ""
        title = unquote_plus(title) if title else ""

        if video_url.startswith("magnet:") or video_url.endswith(".torrent"):
            elementum_url = f"plugin://plugin.video.elementum/play?uri={quote_plus(video_url)}"
            li = xbmcgui.ListItem(path=elementum_url)
            xbmcplugin.setResolvedUrl(self.handle, True, listitem=li)
        else:
            li = xbmcgui.ListItem(path=video_url)
            try:
                info_tag = li.getVideoInfoTag()
                info_tag.setTitle(title)
                info_tag.setMediaType('movie')
            except AttributeError:
                li.setInfo(type="Video", infoLabels={"Title": title})
            xbmcplugin.setResolvedUrl(self.handle, True, listitem=li)

    # ==========================================
    # Helpers de UI
    # ==========================================
    def add_dir(self, name, url):
        """Añade un directorio/carpeta a la lista."""
        item = xbmcgui.ListItem(name)
        item.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        xbmcplugin.addDirectoryItem(self.handle, url, item, isFolder=True)

    def add_video(self, name, url, cover, background, plot, rating, year):
        """Añade un elemento reproducible con menú contextual de favoritos."""
        play_url = self._build_url('reproducir', video_url=url, title=name)
        item = xbmcgui.ListItem(name)
        item.setArt({
            'icon': cover, 'thumb': cover,
            'poster': cover, 'fanart': background
        })

        try:
            info_tag = item.getVideoInfoTag()
            info_tag.setTitle(name)
            info_tag.setPlot(plot)
            info_tag.setRating(rating)
            info_tag.setMediaType('movie')
            if year:
                try:
                    info_tag.setYear(int(year))
                except (ValueError, TypeError):
                    pass
        except AttributeError:
            info = {"title": name, "plot": plot, "rating": rating}
            if year:
                try: info["year"] = int(year)
                except: pass
            item.setInfo(type="Video", infoLabels=info)

        # Menú contextual: Favoritos
        ctx_menu = []
        if FavoritesManager.is_fav(url):
            remove_url = self._build_url('remove_fav', video_url=url)
            ctx_menu.append(("❌ Quitar de Favoritos", f"RunPlugin({remove_url})"))
        else:
            add_url = self._build_url('add_fav', video_url=url, title=name)
            ctx_menu.append(("⭐ Añadir a Favoritos", f"RunPlugin({add_url})"))

        if ctx_menu:
            item.addContextMenuItems(ctx_menu)

        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(self.handle, play_url, item, isFolder=False)


if __name__ == '__main__':
    engine = JSONEngine()
    engine.run()